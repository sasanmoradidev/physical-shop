import { prisma } from "@/lib/prisma";

type Props = {
  params: Promise<{
    id: string;
  }>;
};

export default async function OrderDetailPage(
  { params }: Props
) {
  const { id } = await params;

  const order =
    await prisma.order.findUnique({
      where: { id },

      include: {
        user: true,
        address: true,

        items: {
          include: {
            product: true,
          },
        },
      },
    });

  if (!order) {
    return <div>یافت نشد</div>;
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">
        سفارش
      </h1>

      <p>
        مشتری:
        {" "}
        {order.user.name}
      </p>

      <p>
        وضعیت:
        {" "}
        {order.status}
      </p>

      <hr className="my-4" />

      {order.items.map((item) => (
        <div
          key={item.id}
          className="flex justify-between border-b py-2"
        >
          <span>
            {item.product.title}
          </span>

          <span>
            {item.quantity}
          </span>

          <span>
            {item.price.toString()}
          </span>
        </div>
      ))}
    </div>
  );
}